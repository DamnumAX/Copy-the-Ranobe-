package app.ranobe

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Book(val id: String, var name: String, val fmt: String)
class Sess(val id: String, var name: String, val bookId: String, val startUrl: String,
           var lastUrl: String, var nextUrl: String, var count: Int, var state: String)
class Ch(val title: String, val url: String, val paras: List<String>)

class Store(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("ranobe", Context.MODE_PRIVATE)
    var theme: Int
        get() = p.getInt("theme", 1)
        set(v) { p.edit().putInt("theme", v).apply() }
    var delaySec: Int
        get() = p.getInt("delay", 2)
        set(v) { p.edit().putInt("delay", v).apply() }
    var blacklist: String
        get() = p.getString("bl", "") ?: ""
        set(v) { p.edit().putString("bl", v).apply() }

    fun sites(): List<String> = (p.getStringSet("sites", emptySet()) ?: emptySet()).sorted()
    fun addSite(h: String) { p.edit().putStringSet("sites", (sites() + h).toSet()).apply() }
    fun delSite(h: String) { p.edit().putStringSet("sites", (sites() - h).toSet()).apply() }

    fun books(): MutableList<Book> {
        val a = JSONArray(p.getString("books", "[]"))
        return MutableList(a.length()) { val o = a.getJSONObject(it); Book(o.getString("id"), o.getString("name"), o.getString("fmt")) }
    }
    fun saveBooks(l: List<Book>) {
        p.edit().putString("books", JSONArray(l.map { JSONObject().put("id", it.id).put("name", it.name).put("fmt", it.fmt) }).toString()).apply()
    }
    fun sessions(): MutableList<Sess> {
        val a = JSONArray(p.getString("sess", "[]"))
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Sess(o.getString("id"), o.getString("name"), o.getString("book"), o.getString("start"),
                o.getString("last"), o.getString("next"), o.getInt("count"), o.getString("state"))
        }
    }
    fun saveSessions(l: List<Sess>) {
        p.edit().putString("sess", JSONArray(l.map {
            JSONObject().put("id", it.id).put("name", it.name).put("book", it.bookId).put("start", it.startUrl)
                .put("last", it.lastUrl).put("next", it.nextUrl).put("count", it.count).put("state", it.state)
        }).toString()).apply()
    }

    private fun f(id: String) = File(ctx.filesDir, "$id.jsonl")
    fun addChapter(b: String, c: Ch) {
        f(b).appendText(JSONObject().put("t", c.title).put("u", c.url).put("p", JSONArray(c.paras)).toString() + "\n")
    }
    fun chapters(b: String): List<Ch> =
        if (!f(b).exists()) emptyList() else f(b).readLines().filter { it.isNotBlank() }.map {
            val o = JSONObject(it); val a = o.getJSONArray("p")
            Ch(o.getString("t"), o.getString("u"), List(a.length()) { i -> a.getString(i) })
        }
    fun count(b: String): Int = if (!f(b).exists()) 0 else f(b).useLines { s -> s.count { it.isNotBlank() } }
    fun delBook(b: String) { f(b).delete() }
}
