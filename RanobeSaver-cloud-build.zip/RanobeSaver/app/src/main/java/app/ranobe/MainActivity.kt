package app.ranobe

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.text.InputType
import android.view.*
import android.webkit.*
import android.widget.*
import org.json.JSONObject
import org.json.JSONTokener
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

class Pal(val name: String, val light: Boolean, b: Long, c: Long, t: Long, s: Long, a: Long, o: Long) {
    val bg = b.toInt(); val card = c.toInt(); val tx = t.toInt(); val sub = s.toInt(); val ac = a.toInt(); val onAc = o.toInt()
}

val PALS = listOf(
    Pal("Светлая", true, 0xFFF4F6FB, 0xFFFFFFFF, 0xFF1B1F2A, 0xFF6B7280, 0xFF4F63F5, 0xFFFFFFFF),
    Pal("Тёмная", false, 0xFF12141C, 0xFF1D212C, 0xFFE8EAF0, 0xFF98A0B3, 0xFF7C8CFF, 0xFF0E1020),
    Pal("AMOLED", false, 0xFF000000, 0xFF111111, 0xFFEDEDED, 0xFF9A9A9A, 0xFF3DDC97, 0xFF000000),
    Pal("Сепия", true, 0xFFF3E9D2, 0xFFFBF4E4, 0xFF3B2F20, 0xFF8A7A62, 0xFFB5651D, 0xFFFFFFFF),
    Pal("Океан", false, 0xFF0B1E2D, 0xFF12304A, 0xFFE3F2FD, 0xFF8FB3CC, 0xFF29B6F6, 0xFF04202F),
    Pal("Лес", true, 0xFFE8F0E6, 0xFFF7FBF5, 0xFF1E2B20, 0xFF62766A, 0xFF2E7D32, 0xFFFFFFFF)
)

// Извлекает из открытой страницы: капчу / текст главы / название / ссылку «дальше».
private val JS = """
(function(){
function T(e){return(e.innerText||'').trim()}
function ok(p){if(p.closest('nav,header,footer,aside,form,button,[role=navigation]'))return false;var t=T(p);if(!t)return false;var lt=0,as=p.querySelectorAll('a');for(var k=0;k<as.length;k++)lt+=T(as[k]).length;return lt<=t.length*0.6}
var head=(document.title||'')+' '+(document.body?(document.body.innerText||'').slice(0,300):'');
var bodyLen=document.body?T(document.body).length:0;
if(/just a moment|verify you are human|are you human|captcha|checking your browser|attention required|не робот|проверка безопасности/i.test(head)||(document.querySelector('#challenge-form,#cf-challenge-running,.cf-turnstile,.g-recaptcha,.h-captcha,iframe[src*="captcha"],iframe[src*="challenges.cloudflare"]')&&bodyLen<600))return JSON.stringify({captcha:true});
var map=new Map(),ps=document.querySelectorAll('p');
for(var i=0;i<ps.length;i++){var p=ps[i];if(!ok(p))continue;map.set(p.parentElement,(map.get(p.parentElement)||0)+T(p).length)}
var best=null,bs=0;map.forEach(function(v,k){if(v>bs){bs=v;best=k}});
var paras=[];
if(best&&bs>150){for(var j=0;j<best.children.length;j++){var c=best.children[j];if(c.tagName==='P'&&ok(c))paras.push(T(c))}}
if(!paras.length){var cs=document.querySelectorAll('article,main,[class*=chapter],[id*=chapter],[class*=content],[class*=reader]'),bl=0,be=null;
for(var m=0;m<cs.length;m++){var L=T(cs[m]).length;if(L>bl&&L<200000){bl=L;be=cs[m]}}
if(be)paras=T(be).split(/\n+/).map(function(s){return s.trim()}).filter(Boolean)}
var h=document.querySelector('article h1,main h1,h1,article h2,h2');var title=h?T(h):'';
if(!title)title=(document.title||'').split(/[|\-–—]/)[0].trim();
if(title.length>120)title=title.slice(0,120);
var n=document.querySelector('a[rel=next]');
if(!n){var al=document.querySelectorAll('a[href]');for(var q=0;q<al.length;q++){var a=al[q],s=(T(a)+' '+(a.getAttribute('aria-label')||'')+' '+(a.title||'')).toLowerCase().trim();
if(/(^|\s)(next|следующ|далее|вперёд|вперед)/.test(s)&&!/prev|предыдущ|назад/.test(s)){n=a;break}}}
var nx='';
if(n&&n.href&&n.href.indexOf('javascript')!==0&&!/disabled/i.test((n.className||'')+' '+(n.getAttribute('aria-disabled')||''))&&n.href.split('#')[0]!==location.href.split('#')[0])nx=n.href;
return JSON.stringify({title:title,paras:paras,next:nx,url:location.href});
})()
""".trimIndent()

class MainActivity : Activity() {
    private lateinit var st: Store
    private lateinit var pal: Pal
    private lateinit var web: WebView
    private val h = Handler(Looper.getMainLooper())
    private val tabs = ArrayList<View>()
    private val tabBtns = ArrayList<TextView>()
    private var tab = 0
    private lateinit var urlE: EditText
    private lateinit var cntE: EditText
    private lateinit var nameE: EditText
    private lateinit var sessE: EditText
    private lateinit var delayE: EditText
    private lateinit var blE: EditText
    private lateinit var siteE: EditText
    private lateinit var bookB: Button
    private lateinit var fmtB: Button
    private lateinit var startB: Button
    private lateinit var statusT: TextView
    private lateinit var statusB: TextView
    private lateinit var bookBox: LinearLayout
    private lateinit var sessBox: LinearLayout
    private lateinit var accBox: LinearLayout

    private var books = mutableListOf<Book>()
    private var sessions = mutableListOf<Sess>()
    private var selBook: Book? = null
    private var resumeS: Sess? = null
    private var fmt = "EPUB"
    private var book: Book? = null
    private var sess: Sess? = null
    private var running = false
    private var paused = false
    private var waiting = false
    private var guessed = false
    private var gen = 0
    private var lastLen = -1
    private var remaining = 0
    private var done = 0
    private var prevHash = 0
    private val seen = HashSet<String>()

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rect(c: Int, r: Int = 14) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, sz: Float = 15f, c: Int = pal.tx, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun btn(t: String, primary: Boolean = true, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(if (primary) pal.onAc else pal.tx)
        background = rect(if (primary) pal.ac else pal.card, 12); setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { f() }
    }
    private fun edit(hint: String) = EditText(this).apply {
        this.hint = hint; setTextColor(pal.tx); setHintTextColor(pal.sub); background = rect(pal.card, 12)
        setPadding(dp(12), dp(10), dp(12), dp(10)); textSize = 15f
    }
    private fun lp(w: Int = -1, h: Int = -2, wt: Float = 0f, m: Int = 6) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(m), dp(m), dp(m), dp(m)) }
    private fun col(pad: Int = 10) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(pad), dp(pad), dp(pad), dp(pad)) }
    private fun card() = col(12).apply { background = rect(pal.card) }
    private fun row(vararg v: View) = LinearLayout(this).also { r -> v.forEach { r.addView(it, lp(0, -2, 1f, 3)) } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun setStatus(m: String) { statusT.text = m; statusB.text = m }
    private fun ask(title: String, init: String, ok: (String) -> Unit) {
        val e = EditText(this).apply { setText(init) }
        AlertDialog.Builder(this).setTitle(title).setView(e)
            .setPositiveButton("OK") { _, _ -> ok(e.text.toString().trim()) }.setNegativeButton("Отмена", null).show()
    }
    private fun confirm(msg: String, ok: () -> Unit) =
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Да") { _, _ -> ok() }.setNegativeButton("Нет", null).show()

    // ---------- lifecycle ----------
    override fun onCreate(sv: Bundle?) {
        super.onCreate(sv)
        st = Store(this); pal = PALS[st.theme.coerceIn(0, PALS.size - 1)]
        books = st.books(); sessions = st.sessions()
        window.statusBarColor = pal.bg; window.navigationBarColor = pal.bg
        if (pal.light) window.decorView.systemUiVisibility = 0x2010
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.bg) }
        setContentView(root)
        val frame = FrameLayout(this)
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        tabs += buildDownload(); tabs += buildBrowser(); tabs += buildSessions(); tabs += buildAccounts(); tabs += buildSettings()
        tabs.forEach { frame.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        val bar = LinearLayout(this).apply { setBackgroundColor(pal.card) }
        listOf("⬇\nСкачать", "🌐\nБраузер", "📚\nСессии", "👤\nАккаунты", "🎨\nТема").forEachIndexed { i, t ->
            val b = TextView(this).apply {
                text = t; gravity = Gravity.CENTER; textSize = 11f; setPadding(0, dp(8), 0, dp(8)); setOnClickListener { showTab(i) }
            }
            tabBtns += b; bar.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        showTab(0); handleIntent(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleIntent(i) }
    private fun handleIntent(i: Intent?) {
        val ii = i ?: return
        if (ii.action == Intent.ACTION_SEND) {
            Regex("https?://\\S+").find(ii.getStringExtra(Intent.EXTRA_TEXT) ?: "")?.value?.let {
                urlE.setText(it); showTab(0); setStatus("Ссылка получена. Выберите файл и нажмите «Начать копирование».")
            }
        }
    }
    override fun onPause() { super.onPause(); saveFields(); CookieManager.getInstance().flush() }
    override fun onDestroy() { super.onDestroy(); gen++; web.destroy() }
    @Deprecated("back")
    override fun onBackPressed() {
        if (tab == 1 && web.canGoBack()) web.goBack() else if (tab != 0) showTab(0) else super.onBackPressed()
    }

    private fun showTab(i: Int) {
        tab = i
        tabs.forEachIndexed { j, v -> v.visibility = if (i == j) View.VISIBLE else View.GONE }
        tabBtns.forEachIndexed { j, t -> t.setTextColor(if (i == j) pal.ac else pal.sub) }
        if (i == 2) refreshSessions()
        if (i == 3) refreshAccounts()
    }
    private fun saveFields() {
        st.delaySec = delayE.text.toString().toIntOrNull()?.coerceIn(0, 60) ?: 2
        st.blacklist = blE.text.toString()
    }
    private fun saveSess() = st.saveSessions(sessions)
    private fun clip() = (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.text?.toString() ?: ""
    private fun openUrl(u: String, msg: String = "") {
        if (running) { toast("Сначала остановите копирование"); return }
        if (!u.startsWith("http")) { toast("Нужна ссылка, начинающаяся с http"); return }
        web.loadUrl(u); showTab(1); if (msg.isNotEmpty()) setStatus(msg)
    }

    // ---------- tabs ----------
    private fun buildDownload(): View {
        val c = col()
        c.addView(tv("Ранобэ → файл", 22f, pal.tx, true), lp())
        c.addView(tv("Вставьте ссылку на главу или поделитесь ссылкой из браузера прямо в приложение.", 13f, pal.sub), lp())
        urlE = edit("Ссылка на главу (https://…)"); c.addView(urlE, lp())
        c.addView(row(btn("Вставить", false) { urlE.setText(clip()) }, btn("Открыть в браузере", false) { openUrl(urlE.text.toString()) }))
        cntE = edit("Сколько глав (пусто = до конца)"); cntE.inputType = InputType.TYPE_CLASS_NUMBER; c.addView(cntE, lp())
        bookB = btn("", false) { pickBook() }; c.addView(bookB, lp())
        nameE = edit("Название нового файла"); c.addView(nameE, lp())
        fmtB = btn("", false) { fmt = if (fmt == "EPUB") "TXT" else "EPUB"; refreshForm() }; c.addView(fmtB, lp())
        sessE = edit("Название сессии (необязательно)"); c.addView(sessE, lp())
        startB = btn("▶ Начать копирование") { if (running) stop() else start() }; c.addView(startB, lp())
        statusT = tv("Готово к работе.", 14f, pal.sub); c.addView(statusT, lp())
        refreshForm()
        return ScrollView(this).apply { addView(c) }
    }
    private fun refreshForm() {
        val sb = selBook
        bookB.text = "Файл: " + (if (sb == null) "создать новый" else sb.name + "." + sb.fmt.lowercase()) + "  ▾"
        val v = if (sb == null) View.VISIBLE else View.GONE
        nameE.visibility = v; fmtB.visibility = v
        fmtB.text = "Формат нового файла: $fmt (нажмите, чтобы сменить)"
    }
    private fun pickBook() {
        val names = listOf("＋ Новый файл") + books.map { it.name + "." + it.fmt.lowercase() }
        AlertDialog.Builder(this).setTitle("Файл для записи").setItems(names.toTypedArray()) { _, i ->
            selBook = if (i == 0) null else books[i - 1]; refreshForm()
        }.show()
    }

    private fun buildBrowser(): View {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statusB = tv("Здесь можно войти в аккаунт и пройти проверку «я не робот».", 13f, pal.sub); c.addView(statusB, lp())
        c.addView(row(btn("◀", false) { if (web.canGoBack()) web.goBack() }, btn("Продолжить") { resume() },
            btn("Эта страница → ссылка", false) { urlE.setText(web.url ?: ""); showTab(0) }))
        web = WebView(this)
        web.settings.javaScriptEnabled = true; web.settings.domStorageEnabled = true
        web.settings.useWideViewPort = true; web.settings.loadWithOverviewMode = true
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, true) }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = r.url.scheme?.startsWith("http") != true
            override fun onPageFinished(v: WebView, u: String?) {
                if (running && !waiting) { gen++; lastLen = -1; val t = gen; h.postDelayed({ poll(t, 0) }, 800) }
            }
        }
        c.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        return c
    }

    private fun buildSessions(): View {
        val c = col()
        c.addView(tv("Файлы", 20f, pal.tx, true), lp())
        bookBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c.addView(bookBox)
        c.addView(tv("Сессии копирования", 20f, pal.tx, true), lp())
        sessBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c.addView(sessBox)
        return ScrollView(this).apply { addView(c) }
    }
    private fun refreshSessions() {
        bookBox.removeAllViews(); sessBox.removeAllViews()
        if (books.isEmpty()) bookBox.addView(tv("Пока нет файлов.", 14f, pal.sub), lp())
        books.forEach { b ->
            val k = card()
            k.addView(tv(b.name + "." + b.fmt.lowercase(), 16f, pal.tx, true))
            k.addView(tv("Глав в файле: ${st.count(b.id)}  ·  Загрузки/Ranobe", 13f, pal.sub))
            k.addView(row(
                btn("Выбрать", false) { selBook = b; refreshForm(); showTab(0) },
                btn("Сохранить", false) { toast(export(b)) },
                btn("Удалить", false) { confirm("Удалить «${b.name}» из приложения? Готовый файл в «Загрузках» останется.") { delBook(b) } }))
            bookBox.addView(k, lp())
        }
        if (sessions.isEmpty()) sessBox.addView(tv("Пока нет сессий.", 14f, pal.sub), lp())
        sessions.reversed().forEach { s ->
            val b = books.find { it.id == s.bookId }
            val k = card()
            k.addView(tv(s.name, 16f, pal.tx, true))
            k.addView(tv("Файл: ${b?.name ?: "?"}  ·  глав: ${s.count}  ·  ${s.state}", 13f, pal.sub))
            k.addView(tv("Старт: ${s.startUrl}\nКонец: ${s.lastUrl.ifEmpty { "—" }}", 12f, pal.sub).apply { setTextIsSelectable(true) })
            k.addView(row(
                btn("Продолжить", true) {
                    if (running) toast("Сначала остановите копирование") else if (b != null) {
                        resumeS = s; selBook = b; urlE.setText(s.nextUrl); sessE.setText(s.name); refreshForm(); showTab(0)
                        setStatus("Продолжение сессии «${s.name}» с последней ссылки. Укажите число глав и нажмите «Начать копирование».")
                    }
                },
                btn("Имя", false) { ask("Название сессии", s.name) { n -> if (n.isNotEmpty()) { s.name = n; saveSess(); refreshSessions() } } },
                btn("Удалить", false) { confirm("Удалить запись о сессии? Главы в файле останутся.") { sessions.remove(s); saveSess(); refreshSessions() } }))
            sessBox.addView(k, lp())
        }
    }
    private fun delBook(b: Book) {
        st.delBook(b.id); books.remove(b); st.saveBooks(books)
        sessions.removeAll { it.bookId == b.id }; saveSess()
        if (selBook?.id == b.id) selBook = null
        refreshForm(); refreshSessions()
    }

    private fun buildAccounts(): View {
        val c = col()
        c.addView(tv("Аккаунты сайтов", 20f, pal.tx, true), lp())
        c.addView(tv("Войдите на сайте один раз в «Браузере» — вход сохранится. Здесь можно выйти из аккаунта.", 13f, pal.sub), lp())
        siteE = edit("Адрес сайта, например wtr-lab.com"); c.addView(siteE, lp())
        c.addView(btn("Добавить и войти") {
            val u = siteE.text.toString().trim()
            if (u.isNotEmpty()) {
                val full = if (u.startsWith("http")) u else "https://$u"
                Uri.parse(full).host?.let { st.addSite(it) }
                openUrl(full, "Войдите в аккаунт на сайте и вернитесь в приложение. Вход сохранится."); refreshAccounts()
            }
        }, lp())
        accBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c.addView(accBox)
        return ScrollView(this).apply { addView(c) }
    }
    private fun refreshAccounts() {
        accBox.removeAllViews()
        if (st.sites().isEmpty()) accBox.addView(tv("Список пуст.", 14f, pal.sub), lp())
        st.sites().forEach { host ->
            val has = !CookieManager.getInstance().getCookie("https://$host").isNullOrEmpty()
            val k = card()
            k.addView(tv(host, 16f, pal.tx, true))
            k.addView(tv(if (has) "🍪 Данные входа/сайта сохранены" else "⚪ Сохранённых данных нет", 13f, pal.sub))
            k.addView(row(
                btn("Войти / открыть", true) { openUrl("https://$host", "Войдите в аккаунт и вернитесь в приложение.") },
                btn("Выйти", false) { logout(host); refreshAccounts() },
                btn("Убрать", false) { st.delSite(host); refreshAccounts() }))
            accBox.addView(k, lp())
        }
    }
    private fun logout(host: String) {
        val cm = CookieManager.getInstance()
        val doms = mutableSetOf(host, ".$host")
        val parts = host.split(".")
        if (parts.size > 2) doms += "." + parts.takeLast(2).joinToString(".")
        cm.getCookie("https://$host")?.split(";")?.forEach {
            val n = it.substringBefore("=").trim()
            if (n.isNotEmpty()) {
                cm.setCookie("https://$host", "$n=; Max-Age=0; Path=/")
                doms.forEach { d -> cm.setCookie("https://$host", "$n=; Max-Age=0; Path=/; Domain=$d") }
            }
        }
        cm.flush(); WebStorage.getInstance().deleteAllData()
        toast("Вы вышли из аккаунта на $host")
    }

    private fun buildSettings(): View {
        val c = col()
        c.addView(tv("Тема оформления", 20f, pal.tx, true), lp())
        PALS.forEachIndexed { i, p ->
            c.addView(Button(this).apply {
                text = p.name + if (i == st.theme) "  ✓" else ""; isAllCaps = false; setTextColor(p.tx)
                background = GradientDrawable().apply { setColor(p.bg); cornerRadius = dp(12).toFloat(); setStroke(dp(2), p.ac) }
                setOnClickListener {
                    if (running) toast("Остановите копирование, затем меняйте тему") else { saveFields(); st.theme = i; recreate() }
                }
            }, lp())
        }
        c.addView(tv("Копирование", 20f, pal.tx, true), lp())
        delayE = edit("Пауза между главами, сек (рекомендуется 2–5)"); delayE.inputType = InputType.TYPE_CLASS_NUMBER
        delayE.setText(st.delaySec.toString()); c.addView(delayE, lp())
        blE = edit("Фразы, которые нужно вырезать (по одной в строке)"); blE.minLines = 4; blE.gravity = Gravity.TOP or Gravity.START
        blE.setText(st.blacklist); c.addView(blE, lp())
        c.addView(tv("Любой абзац, содержащий такую фразу, не попадёт в файл. Типичный мусор сайтов (©, «О сайте», «Контакты», навигация) убирается автоматически.", 12f, pal.sub), lp())
        return ScrollView(this).apply { addView(c) }
    }

    // ---------- copying ----------
    private fun start() {
        val url = urlE.text.toString().trim()
        if (!url.startsWith("http")) { toast("Вставьте ссылку на главу (начинается с http)"); return }
        saveFields()
        val rs = resumeS
        val bk: Book = if (rs != null) (books.find { it.id == rs.bookId } ?: return) else selBook ?: run {
            var n = nameE.text.toString().trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .ifEmpty { "Ранобэ " + SimpleDateFormat("dd.MM HH-mm", Locale.getDefault()).format(Date()) }
            if (books.any { it.name == n && it.fmt == fmt }) n += " (" + (books.size + 1) + ")"
            Book(UUID.randomUUID().toString(), n, fmt).also { books.add(it); st.saveBooks(books); selBook = it; refreshForm() }
        }
        val n = cntE.text.toString().toIntOrNull() ?: 0
        remaining = if (n <= 0) Int.MAX_VALUE else n
        val s = rs?.also { it.state = "Идёт" } ?: Sess(UUID.randomUUID().toString(),
            sessE.text.toString().trim().ifEmpty { "Сессия ${sessions.count { it.bookId == bk.id } + 1} · ${bk.name}" },
            bk.id, url, "", url, 0, "Идёт").also { sessions.add(it) }
        saveSess(); resumeS = null
        Uri.parse(url).host?.let { st.addSite(it) }
        book = bk; sess = s; done = 0; prevHash = 0; seen.clear(); guessed = false
        running = true; paused = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startB.text = "■ Остановить"; setStatus("Загружаю страницу…"); doLoad(url)
    }
    private fun stop() = finish("Остановлено. Скопировано глав: $done.", "Остановлена")
    private fun finish(msg: String, state: String = "Завершена") {
        running = false; paused = false; waiting = false; gen++
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        sess?.state = state; saveSess()
        val info = book?.let { if (done > 0 || st.count(it.id) > 0) "\n" + export(it) else "" } ?: ""
        startB.text = "▶ Начать копирование"
        setStatus(msg + info)
    }
    private fun resume() {
        if (!running || !paused) { toast("Продолжать нечего"); return }
        paused = false; waiting = false; gen++; lastLen = -1; val t = gen
        setStatus("Продолжаю…"); poll(t, 0)
    }
    private fun doLoad(u: String) { gen++; lastLen = -1; waiting = false; paused = false; web.loadUrl(u) }

    private fun poll(t: Int, n: Int) {
        if (t != gen || !running) return
        web.evaluateJavascript(JS) { raw ->
            if (t != gen || !running) return@evaluateJavascript
            val o = try { JSONObject(JSONTokener(raw).nextValue() as String) } catch (e: Exception) { null }
            val a = o?.optJSONArray("paras")
            val len = if (a == null) 0 else (0 until a.length()).sumOf { a.getString(it).length }
            when {
                o != null && o.optBoolean("captcha") -> {
                    if (!paused) { paused = true; showTab(1) }
                    setStatus("Нужна проверка «я не робот». Пройдите её в этом окне — копирование продолжится само (или нажмите «Продолжить»).")
                    h.postDelayed({ poll(t, 0) }, 3000)
                }
                o != null && len > 80 && len == lastLen -> handleChapter(o)
                n >= 25 -> fail()
                else -> { lastLen = len; h.postDelayed({ poll(t, n + 1) }, 1000) }
            }
        }
    }
    private fun fail() {
        if (guessed) { finish("Главы на сайте закончились — копирование завершено."); return }
        paused = true; waiting = false; gen++
        showTab(1)
        setStatus("Не удалось получить текст главы. Возможно, нужен вход в аккаунт, проверка или глава платная. Решите это здесь и нажмите «Продолжить» (или остановите копирование).")
    }
    private fun clean(l: List<String>): List<String> {
        val bl = st.blacklist.lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        val junk = Regex("(?i)(©|all rights reserved|все права защищены|^(about us|about|contact us|contact|privacy policy|terms( of (use|service))?|cookie policy|dmca|share|next|prev|previous|о сайте|контакты|контактные данные|политика конфиденциальности|следующая|предыдущая)\\W*$|^https?://\\S+$)")
        return l.map { it.replace(Regex("[\\u200B-\\u200D\\uFEFF]"), "").replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotEmpty() && !(it.length < 140 && junk.containsMatchIn(it)) && bl.none { b -> it.lowercase().contains(b) } }
    }
    private fun guessNext(u: String): String {
        val m = Regex("(?i)(chapter|chap|ch|glava|глава|episode|ep)[-_/=]?(\\d+)(?!.*\\d)").find(u) ?: return ""
        val g = m.groups[2] ?: return ""
        return u.replaceRange(g.range, (g.value.toLong() + 1).toString())
    }
    private fun handleChapter(o: JSONObject) {
        gen++; waiting = true; paused = false
        val a = o.getJSONArray("paras")
        val paras = clean(List(a.length()) { a.getString(it) })
        val cur = o.optString("url")
        if (paras.isEmpty()) { fail(); return }
        if (paras.hashCode() == prevHash || cur in seen) { finish("Достигнут конец: страница повторяет предыдущую."); return }
        prevHash = paras.hashCode(); seen += cur
        val b = book!!; val s = sess!!
        val title = o.optString("title").ifBlank { "Глава ${done + 1}" }
        st.addChapter(b.id, Ch(title, cur, paras))
        done++; remaining--
        var next = o.optString("next"); guessed = false
        if (next.isEmpty()) { next = guessNext(cur); guessed = next.isNotEmpty() }
        s.lastUrl = cur; s.nextUrl = next.ifEmpty { cur }; s.count++; saveSess()
        setStatus("✔ Скопировано глав: $done — $title")
        when {
            remaining <= 0 -> finish("Готово: скопировано глав — $done.")
            next.isEmpty() -> finish("Главы на сайте закончились — скопировано: $done.")
            else -> {
                if (done % 20 == 0) export(b)
                h.postDelayed({ if (running) doLoad(next) }, st.delaySec * 1000L + Random.nextLong(0, 800))
            }
        }
    }

    private fun export(b: Book): String = try {
        val chs = st.chapters(b.id)
        if (chs.isEmpty()) "В файле пока нет глав." else {
            val name = b.name + "." + b.fmt.lowercase()
            val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            var uri: Uri? = null
            contentResolver.query(coll, arrayOf(MediaStore.Downloads._ID),
                "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?",
                arrayOf(name, "Download/Ranobe/"), null)?.use { if (it.moveToFirst()) uri = ContentUris.withAppendedId(coll, it.getLong(0)) }
            if (uri == null) uri = contentResolver.insert(coll, ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, if (b.fmt == "EPUB") "application/epub+zip" else "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/Ranobe")
            })
            contentResolver.openOutputStream(uri!!, "wt")!!.use { if (b.fmt == "EPUB") Exporter.epub(b.name, chs, it) else Exporter.txt(chs, it) }
            "Файл сохранён: Загрузки/Ranobe/$name (глав: ${chs.size})"
        }
    } catch (e: Exception) { "Ошибка сохранения файла: ${e.message}" }
}
