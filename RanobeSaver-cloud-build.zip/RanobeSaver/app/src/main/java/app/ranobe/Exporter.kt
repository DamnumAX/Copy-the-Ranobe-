package app.ranobe

import java.io.OutputStream
import java.util.UUID
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Exporter {
    private fun x(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    fun txt(chs: List<Ch>, o: OutputStream) {
        o.write(chs.joinToString("\n\n") { it.title + "\n" + it.paras.joinToString("\n") }.toByteArray())
    }

    fun epub(title: String, chs: List<Ch>, o: OutputStream) {
        val id = "urn:uuid:" + UUID.randomUUID()
        ZipOutputStream(o).use { z ->
            val mt = "application/epub+zip".toByteArray()
            val e = ZipEntry("mimetype")
            e.method = ZipEntry.STORED; e.size = mt.size.toLong(); e.compressedSize = mt.size.toLong()
            val crc = CRC32(); crc.update(mt); e.crc = crc.value
            z.putNextEntry(e); z.write(mt); z.closeEntry()
            fun put(n: String, s: String) { z.putNextEntry(ZipEntry(n)); z.write(s.toByteArray()); z.closeEntry() }
            put("META-INF/container.xml", """<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>""")
            val man = StringBuilder(); val spine = StringBuilder(); val nav = StringBuilder()
            chs.forEachIndexed { i, c ->
                man.append("""<item id="c$i" href="c$i.xhtml" media-type="application/xhtml+xml"/>""")
                spine.append("""<itemref idref="c$i"/>""")
                nav.append("""<navPoint id="n$i" playOrder="${i + 1}"><navLabel><text>${x(c.title)}</text></navLabel><content src="c$i.xhtml"/></navPoint>""")
                put("OEBPS/c$i.xhtml", """<?xml version="1.0" encoding="UTF-8"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>${x(c.title)}</title></head><body><h2>${x(c.title)}</h2>${c.paras.joinToString("") { "<p>${x(it)}</p>" }}</body></html>""")
            }
            put("OEBPS/content.opf", """<?xml version="1.0" encoding="UTF-8"?><package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="bid"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>${x(title)}</dc:title><dc:language>ru</dc:language><dc:creator>Ranobe Saver</dc:creator><dc:identifier id="bid">$id</dc:identifier></metadata><manifest><item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>$man</manifest><spine toc="ncx">$spine</spine></package>""")
            put("OEBPS/toc.ncx", """<?xml version="1.0" encoding="UTF-8"?><ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head><meta name="dtb:uid" content="$id"/></head><docTitle><text>${x(title)}</text></docTitle><navMap>$nav</navMap></ncx>""")
        }
    }
}
